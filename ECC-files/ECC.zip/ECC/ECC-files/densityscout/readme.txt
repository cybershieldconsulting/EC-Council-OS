DensityScout from http://www.cert.at/downloads/software/densityscout_en.html

