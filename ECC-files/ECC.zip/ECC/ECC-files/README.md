# SIFT Files

Track all issues at https://github.com/sans-dfir/sift/issues

## Overview

Random set of files that are needed for a proper configured SIFT workstation.
